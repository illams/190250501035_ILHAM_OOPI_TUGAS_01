/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasitabungan;

/**
 *
 * @author illam
 *///import required classes and packages   
import java.util.Scanner;  
  
//tugaspengganti 
public class AplikasiTabungan  
{  
     
    public static void main(String args[] )  
    {  
        //deklarasi jumlah tanbungan, penarikan, and deposit  
        int tabungan = 1000000, penarikan, deposit;  
          
        //pengimputan
        Scanner sc = new Scanner(System.in);  
          
        //kondisi loop
        while(true)  
        {  
            System.out.println("Pilih salah satu menu :"); 
            System.out.println("========================"); 
            System.out.println("Pilih 1 untuk Penarikan");  
            System.out.println("Pilih 2 untuk Deposit");  
            System.out.println("Pilih 3 untuk Periksa Tabungan");  
            System.out.println("Pilih 4 untuk keluar");  
            System.out.print("Masukkan nilai :");  
              
            //get hasil inputan  
            int pilihan = sc.nextInt();  
            switch(pilihan)  
            {  
                case 1:  
        System.out.print("masukkan jumlah uang yang akan di tarik :");  
                      
        //input jumlh penarikan
        penarikan = sc.nextInt();  
                      
        //cek jumlh tabungan 
        if(tabungan >= penarikan)  
        {  
            //pengurangan jumlh tabungan hasil penarikan 
            tabungan = tabungan - penarikan;  
            System.out.println("Silahkan ambil uang anda"); 
            System.out.println("Sisa Tabungan anda : "+tabungan);  
        }  
        else  
        {  
            //tampil error
            System.out.println("Jumlah Tabungan tidak mencukupi");  
        }  
        System.out.println("");  
        break;  
   
                case 2:  
                      
        System.out.print("masukkan nilai uang:");  
                      
        //input deposit 
        deposit = sc.nextInt();  
                      
        //penambahan tabungan
        tabungan = tabungan + deposit;  
        System.out.println("uang anda telah berhasil di deposit");  
        System.out.println("Jumlah Tabungan anda : "+tabungan);
        System.out.println("");  
        break;  
   
                case 3:  
        //tampilkan jumlah tabungan  
        System.out.println("Jumlah Tabungan anda : "+tabungan);  
        System.out.println("");  
        break;  
   
                case 4:  
        //keluar loop  
        System.exit(0);  
            }  
        }  
    }  
}  